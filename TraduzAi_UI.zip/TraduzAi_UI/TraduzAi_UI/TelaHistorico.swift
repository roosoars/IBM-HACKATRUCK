//
//  TelaHistorico.swift
//  TraduzAi_UI
//
//  Created by Turma02-8 on 24/02/25.
//

import SwiftUI

struct TelaHistorico: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    TelaHistorico()
}
