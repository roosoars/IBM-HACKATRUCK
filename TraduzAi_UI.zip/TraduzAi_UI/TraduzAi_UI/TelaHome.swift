//
//  TelaHome.swift
//  TraduzAi_UI
//
//  Created by Turma02-8 on 24/02/25.
//

import SwiftUI

struct TelaHome: View {
    var body: some View {
        VStack{
            
        }
    }
}

#Preview {
    TelaHome()
}
