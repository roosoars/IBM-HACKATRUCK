//
//  TelaTexto.swift
//  TraduzAi_UI
//
//  Created by Turma02-8 on 24/02/25.
//

import SwiftUI

struct TelaTexto: View {
    @State private var linguagens: [paises] = [
            paises(nome: "Ingles", imagem: "ingles"),
            paises(nome: "Portugues", imagem: "portugues"),
            paises(nome: "Espanhol", imagem: "espanhol")
        ]
    
    @State private var selectedlinguage: paises = paises(nome: "Portugues", imagem: "portugues")
        
    var body: some View {
        ZStack{
            Color(.corFundo)
                .edgesIgnoringSafeArea(.top)
            VStack{
                Text("Tradutor de Texto")
                    .font(Font.custom("fontTitulo", size: 16))
                    .fontWeight(.semibold)
                Picker("", selection: $selectedlinguage){
                    ForEach(linguagens, id: \.self) { i in
                        HStack{
                            Image(i.imagem)
                            Text(i.nome)
                        }
                    }
                }.frame(width: 200, height: 48).background(Color(.cor6)).cornerRadius(50).tint(.white).shadow(radius: 3)
            }
        }
    }
}

#Preview {
    TelaTexto()
}
