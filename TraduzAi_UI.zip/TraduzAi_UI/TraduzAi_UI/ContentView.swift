//
//  ContentView.swift
//  TraduzAi_UI
//
//  Created by Turma02-8 on 24/02/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView{
            TelaHome()
                .tabItem{
                    Image("iconHome")
                }
            TelaTexto()
                .tabItem{
                    Image("iconText")
                }
            TelaAudio()
                .tabItem{
                    Image("iconVoz")
                }
            TelaHistorico()
                .tabItem{
                    Image("iconHistorico")
                }
        }
    }
}

#Preview {
    ContentView()
}
