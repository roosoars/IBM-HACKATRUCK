//
//  TraduzAi_UIApp.swift
//  TraduzAi_UI
//
//  Created by Turma02-8 on 24/02/25.
//

import SwiftUI

@main
struct TraduzAi_UIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
