//
//  MODEL.swift
//  TraduzAi_UI
//
//  Created by Turma02-8 on 28/02/25.
//

import Foundation

struct paises : Hashable {
    var nome : String
    var imagem: String
}
